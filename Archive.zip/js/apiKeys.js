
    var googleCalKey = 'AIzaSyCq0AQ90mGz4DqeH7ceeAXR7772U3K7zb4';
    var googleCalId = '0g5lutmp776hpisbovsd7thojo42o924@import.calendar.google.com';

    var weatherApiKey = '11adcfe70b89b2df10b3fcb71b8f2a89';
    var uaGoogleId = 'UA-121305962-1';
